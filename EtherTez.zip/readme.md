# Ether Tez 2.1

A little helper for NFT speculation.
Slightly modifies etherscan.io